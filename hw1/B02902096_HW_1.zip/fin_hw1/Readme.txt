Execution:
using make to compile the source code.
using ./hw1 to execute it.

Input:
1.Number Of CashFlows
2.SpotRates[]
3.CashFlows[]
4.w

Output:
1.Modified Duration
2.Convexity

Sample input:
4
0.053 0.051 0.049 0.047
3 2 3 102
0.3
Sample output:
Modified Duration = 2.9983
Convexity = 12.1813
